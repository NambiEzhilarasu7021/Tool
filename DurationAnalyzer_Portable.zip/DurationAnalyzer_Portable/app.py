"""
Streamlit UI for Duration Analyzer
Allows uploading 3 videos and generating Excel reports for each.
"""

import streamlit as st
import tempfile
import os
from pathlib import Path
from screen_transition_analyzer import ScreenTransitionAnalyzer
import time

# Page configuration
st.set_page_config(
    page_title="Duration Analyzer",
    page_icon="🎬",
    layout="wide"
)

# Title
st.title("🎬 Duration Analyzer")
st.markdown("Upload up to 3 videos to analyze screen transitions and generate Excel reports.")

# Initialize session state
if 'results' not in st.session_state:
    st.session_state.results = {}
if 'analysis_complete' not in st.session_state:
    st.session_state.analysis_complete = False

# Sidebar for configuration
with st.sidebar:
    st.header("⚙️ Configuration")
    frame_sampling_rate = st.slider(
        "Frame Sampling Rate (seconds)",
        min_value=0.1,
        max_value=2.0,
        value=0.5,
        step=0.1,
        help="How often to sample frames from the video"
    )
    similarity_threshold = st.slider(
        "Similarity Threshold",
        min_value=0.70,
        max_value=0.99,
        value=0.90,
        step=0.01,
        help="Threshold for detecting screen transitions (higher = more sensitive)"
    )

# Main content area
st.header("📤 Upload Videos")

# Create three columns for video uploads
col1, col2, col3 = st.columns(3)

uploaded_videos = {}

with col1:
    st.subheader("Video 1")
    video1 = st.file_uploader(
        "Upload first video",
        type=['mp4', 'avi', 'mov', 'mkv'],
        key="video1"
    )
    if video1:
        st.info(f"✅ {video1.name}")
        uploaded_videos[1] = video1

with col2:
    st.subheader("Video 2")
    video2 = st.file_uploader(
        "Upload second video",
        type=['mp4', 'avi', 'mov', 'mkv'],
        key="video2"
    )
    if video2:
        st.info(f"✅ {video2.name}")
        uploaded_videos[2] = video2

with col3:
    st.subheader("Video 3")
    video3 = st.file_uploader(
        "Upload third video",
        type=['mp4', 'avi', 'mov', 'mkv'],
        key="video3"
    )
    if video3:
        st.info(f"✅ {video3.name}")
        uploaded_videos[3] = video3

# Run button with info
st.markdown("---")
col_info, col_button = st.columns([2, 1])
with col_info:
    st.info("ℹ️ **Analysis Time**: Processing time depends on video length. A 1-minute video typically takes 2-5 minutes. The analysis includes frame comparison, OCR text extraction, and Excel report generation.")
with col_button:
    run_button = st.button(
        "🚀 Run Analysis",
        type="primary",
        use_container_width=True,
        disabled=len(uploaded_videos) == 0
    )

if run_button and len(uploaded_videos) > 0:
    # Clear previous results
    st.session_state.results = {}
    st.session_state.analysis_complete = False
    
    # Create persistent results directory
    persistent_results_dir = Path("results")
    persistent_results_dir.mkdir(exist_ok=True)
    
    # Create temporary directory for processing
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Save uploaded videos to temp directory
        video_paths = {}
        for video_num, uploaded_file in uploaded_videos.items():
            video_path = temp_path / f"video_{video_num}_{uploaded_file.name}"
            with open(video_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            video_paths[video_num] = video_path
        
        # Create results directory in temp
        results_dir = temp_path / "results"
        results_dir.mkdir(exist_ok=True)
        
        # Progress bar and status
        progress_bar = st.progress(0)
        status_text = st.empty()
        detail_text = st.empty()
        
        # Process each video
        total_videos = len(video_paths)
        for idx, (video_num, video_path) in enumerate(video_paths.items(), 1):
            video_name = uploaded_videos[video_num].name
            status_text.text(f"📹 Processing Video {video_num}: {video_name}")
            detail_text.text("⏳ Initializing analyzer...")
            
            try:
                # Initialize analyzer
                detail_text.text("⏳ Setting up video analysis...")
                analyzer = ScreenTransitionAnalyzer(
                    video_path=str(video_path),
                    output_folder=str(results_dir),
                    frame_sampling_rate=frame_sampling_rate,
                    similarity_threshold=similarity_threshold
                )
                
                # Run analysis with custom filename
                detail_text.text("⏳ Analyzing video frames (this may take a few minutes for long videos)...")
                output_filename = f"ScreenTransitions_Video{video_num}.xlsx"
                output_file = analyzer.run(output_filename=output_filename)
                
                detail_text.text("✅ Analysis complete! Generating Excel report...")
                
                # Copy to persistent location before temp dir is deleted
                if output_file and output_file.exists():
                    detail_text.text("💾 Saving results...")
                    persistent_file = persistent_results_dir / output_filename
                    import shutil
                    shutil.copy2(output_file, persistent_file)
                    
                    # Store result in session state with persistent path
                    st.session_state.results[video_num] = {
                        'file_path': persistent_file,
                        'video_name': video_name,
                        'status': 'success'
                    }
                    detail_text.text(f"✅ Video {video_num} completed successfully!")
                else:
                    st.session_state.results[video_num] = {
                        'video_name': video_name,
                        'status': 'error',
                        'error': 'Failed to generate Excel file'
                    }
                    detail_text.text(f"❌ Video {video_num} failed to generate Excel file")
                
            except Exception as e:
                st.error(f"❌ Error processing Video {video_num}: {str(e)}")
                st.session_state.results[video_num] = {
                    'video_name': video_name,
                    'status': 'error',
                    'error': str(e)
                }
                detail_text.text(f"❌ Error processing Video {video_num}")
            
            # Update progress
            progress_bar.progress(idx / total_videos)
            if idx < total_videos:
                detail_text.text("⏳ Preparing next video...")
        
        # Mark analysis as complete
        st.session_state.analysis_complete = True
        status_text.text("✅ All Videos Processed!")
        detail_text.text("📊 Results are ready for download below")
        progress_bar.progress(1.0)

# Display results and download buttons
if st.session_state.analysis_complete:
    st.markdown("---")
    st.header("📊 Results")
    
    # Create columns for download buttons
    download_cols = st.columns(3)
    
    for idx, (video_num, result) in enumerate(sorted(st.session_state.results.items())):
        with download_cols[idx]:
            if result['status'] == 'success':
                st.success(f"✅ Video {video_num}")
                st.caption(result['video_name'])
                
                # Read file for download
                if result['file_path'].exists():
                    with open(result['file_path'], "rb") as f:
                        st.download_button(
                            label=f"📥 Download Excel {video_num}",
                            data=f.read(),
                            file_name=f"ScreenTransitions_Video{video_num}.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            key=f"download_{video_num}",
                            use_container_width=True
                        )
            else:
                st.error(f"❌ Video {video_num}")
                st.caption(result['video_name'])
                if 'error' in result:
                    st.caption(f"Error: {result['error']}")

# Footer
st.markdown("---")
st.markdown(
    """
    <div style='text-align: center; color: gray;'>
        <p>Duration Analyzer - Upload videos to analyze screen transitions</p>
    </div>
    """,
    unsafe_allow_html=True
)

