"""
Duration Analyzer
Detects screen transitions in video and records start/end times for each screen.
"""

import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim
import pandas as pd
from pathlib import Path
from datetime import timedelta
from tqdm import tqdm
import pytesseract
from PIL import Image
import re
from openpyxl.drawing.image import Image as XLImage
import tempfile
import os


class ScreenTransitionAnalyzer:
    """Analyzes video to detect screen transitions and record time ranges."""
    
    def __init__(self, video_path, output_folder="results", frame_sampling_rate=0.5, similarity_threshold=0.90):
        """
        Initialize the analyzer.
        
        Args:
            video_path: Path to video file
            output_folder: Folder to save results
            frame_sampling_rate: Seconds between frame samples (lower = more accurate)
            similarity_threshold: SSIM threshold to consider frames as same screen (0-1)
        """
        self.video_path = Path(video_path)
        self.output_folder = Path(output_folder)
        self.frame_sampling_rate = frame_sampling_rate
        self.similarity_threshold = similarity_threshold
        self.output_folder.mkdir(exist_ok=True)
        
        # Define known screen names in order
        self.known_screens = [
            "fire tv",
            "Searching for your remote",
            "USB Power Insufficient",
            "Set Up with Your Phone",
            "Scanning for networks"
        ]
        
    def frame_to_grayscale(self, frame):
        """Convert frame to grayscale and resize for comparison."""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Resize to standard size for comparison (faster and more robust)
        return cv2.resize(gray, (320, 240))
    
    def normalize_text(self, text):
        """Normalize text for comparison (lowercase, remove extra spaces)."""
        if not text:
            return ""
        return ' '.join(str(text).lower().split())
    
    def match_screen_name(self, extracted_text):
        """Match extracted text to known screen names."""
        if not extracted_text:
            return None
        
        extracted_lower = extracted_text.lower()
        
        # Try to match each known screen
        for known_screen in self.known_screens:
            known_lower = known_screen.lower()
            
            # Check if extracted text contains key words from known screen
            # Split known screen into words and check if most words match
            known_words = set(known_lower.split())
            extracted_words = set(extracted_lower.split())
            
            # Calculate how many words match
            matching_words = known_words.intersection(extracted_words)
            
            # If at least 2 words match, or if it's a short phrase and matches
            if len(matching_words) >= min(2, len(known_words)):
                return known_screen
            
            # Also check for direct substring match (for partial text)
            if known_lower in extracted_lower or extracted_lower in known_lower:
                return known_screen
        
        return None
    
    def extract_text_from_frame(self, frame):
        """Extract short text name from a video frame using OCR."""
        try:
            # Focus on top portion of screen where titles/headings usually are
            height, width = frame.shape[:2]
            top_portion = frame[0:int(height*0.4), :]  # Top 40% of screen
            
            # Convert BGR to RGB for PIL
            rgb_frame = cv2.cvtColor(top_portion, cv2.COLOR_BGR2RGB)
            pil_image = Image.fromarray(rgb_frame)
            
            # Extract text using pytesseract with config for single line
            # Try to get larger text first (titles/headings)
            custom_config = r'--oem 3 --psm 6'  # Assume uniform block of text
            text = pytesseract.image_to_string(pil_image, lang='eng', config=custom_config)
            
            # Clean up the text
            # Remove extra whitespace and newlines
            text = ' '.join(text.split())
            
            # Remove special characters but keep spaces and alphanumeric
            text = re.sub(r'[^\w\s-]', '', text)
            
            # Take only first few words (max 5 words for short name)
            words = text.split()
            if len(words) > 5:
                text = ' '.join(words[:5])
            elif len(words) > 0:
                text = ' '.join(words)
            
            # Limit total length to 40 characters max
            if len(text) > 40:
                text = text[:40].strip()
            
            # If no meaningful text found, return None
            if not text or len(text.strip()) < 2:
                return None
                
            return text.strip()
        except pytesseract.TesseractNotFoundError:
            # Tesseract not installed
            return None
        except Exception as e:
            # If OCR fails, return None
            return None
    
    def compare_frames(self, frame1, frame2):
        """Compare two frames using SSIM."""
        gray1 = self.frame_to_grayscale(frame1)
        gray2 = self.frame_to_grayscale(frame2)
        
        # Calculate SSIM
        similarity = ssim(gray1, gray2, data_range=255)
        return similarity
    
    def analyze_video(self):
        """Analyze video to detect screen transitions."""
        print(f"\nOpening video: {self.video_path.name}")
        cap = cv2.VideoCapture(str(self.video_path))
        
        if not cap.isOpened():
            raise ValueError(f"Could not open video: {self.video_path}")
        
        # Get video properties
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = total_frames / fps if fps > 0 else 0
        
        print(f"  FPS: {fps:.2f} | Total Frames: {total_frames} | Duration: {duration:.2f}s")
        
        # Calculate frame interval
        frame_interval = int(fps * self.frame_sampling_rate)
        if frame_interval < 1:
            frame_interval = 1
        
        transitions = []
        current_screen_start = 0.0
        previous_frame = None
        screen_number = 1
        current_screen_frame = None  # Store frame for OCR
        
        print(f"\nAnalyzing frames (sampling every {self.frame_sampling_rate}s)...")
        
        frame_count = 0
        with tqdm(total=total_frames, desc="Processing video", unit="frame") as pbar:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                current_time = frame_count / fps if fps > 0 else 0
                
                # Sample frames at specified interval
                if frame_count % frame_interval == 0:
                    if previous_frame is not None:
                        similarity = self.compare_frames(previous_frame, frame)
                        
                        # If similarity is below threshold, it's a transition
                        if similarity < self.similarity_threshold:
                            # Record the previous screen's end time (text extraction will happen later)
                            transitions.append({
                                'screen': f'Screen {screen_number}',
                                'screen_name': None,  # Will be filled later
                                'screen_frame': current_screen_frame.copy() if current_screen_frame is not None else None,
                                'start_time': current_screen_start,
                                'end_time': current_time,
                                'duration': current_time - current_screen_start
                            })
                            
                            # Start new screen
                            screen_number += 1
                            current_screen_start = current_time
                            current_screen_frame = frame.copy()  # Store first frame of new screen
                    
                    if current_screen_frame is None:
                        # First frame of first screen
                        current_screen_frame = frame.copy()
                    
                    previous_frame = frame.copy()
                
                frame_count += 1
                pbar.update(1)
        
        cap.release()
        
        # Record the last screen
        final_time = (frame_count - 1) / fps if fps > 0 else 0
        if current_screen_start < final_time:
            transitions.append({
                'screen': f'Screen {screen_number}',
                'screen_name': None,  # Will be filled later
                'screen_frame': current_screen_frame.copy() if current_screen_frame is not None else None,
                'start_time': current_screen_start,
                'end_time': final_time,
                'duration': final_time - current_screen_start
            })
        
        print(f"\nDetected {len(transitions)} screen transitions")
        print("Extracting text from screens for naming...")
        
        # Extract text from all screens (keep frames for screenshots)
        for i, trans in enumerate(tqdm(transitions, desc="Extracting text", unit="screen")):
            extracted_text = None
            if trans.get('screen_frame') is not None:
                extracted_text = self.extract_text_from_frame(trans['screen_frame'])
            
            # Try to match extracted text to known screen names
            screen_name = self.match_screen_name(extracted_text)
            
            # If no match found, use extracted text or default name
            if not screen_name:
                if extracted_text:
                    screen_name = extracted_text
                else:
                    screen_name = trans['screen']
            
            trans['screen_name'] = screen_name
            trans['extracted_text'] = extracted_text  # Store for comparison
            # Keep frame for screenshot (will be saved later)
        
        # Merge consecutive screens with the same text
        merged_transitions = []
        i = 0
        while i < len(transitions):
            current = transitions[i]
            start_time = current['start_time']
            end_time = current['end_time']
            screen_name = current['screen_name']
            screen_frame = current.get('screen_frame')
            extracted_text = current.get('extracted_text', '')
            
            # Look ahead to find consecutive screens with same text
            j = i + 1
            while j < len(transitions):
                next_screen = transitions[j]
                next_screen_name = next_screen['screen_name']
                next_extracted_text = next_screen.get('extracted_text', '')
                
                # Normalize both screen names and extracted text
                current_normalized = self.normalize_text(screen_name)
                next_normalized = self.normalize_text(next_screen_name)
                current_extracted_norm = self.normalize_text(extracted_text)
                next_extracted_norm = self.normalize_text(next_extracted_text)
                
                # Check if screens are the same
                is_same = False
                
                # Method 1: Exact match on normalized screen names
                if current_normalized and next_normalized and current_normalized == next_normalized:
                    is_same = True
                # Method 2: Exact match on extracted text (if screen names don't match)
                elif current_extracted_norm and next_extracted_norm and current_extracted_norm == next_extracted_norm:
                    is_same = True
                # Method 3: Word-based matching (at least 2 common words for meaningful text)
                elif current_extracted_norm and next_extracted_norm:
                    current_words = set(current_extracted_norm.split())
                    next_words = set(next_extracted_norm.split())
                    # Remove very short words (1-2 chars) as they're often OCR noise
                    current_words = {w for w in current_words if len(w) > 2}
                    next_words = {w for w in next_words if len(w) > 2}
                    
                    if len(current_words) > 0 and len(next_words) > 0:
                        common_words = current_words.intersection(next_words)
                        # If at least 2 meaningful words match, or if most words match
                        if len(common_words) >= 2:
                            is_same = True
                        elif len(current_words) <= 3 and len(common_words) == len(current_words):
                            # For short phrases, all words must match
                            is_same = True
                
                if is_same:
                    # Same screen - merge by extending end time
                    end_time = next_screen['end_time']
                    # Keep the first frame for screenshot
                    j += 1
                else:
                    break
            
            # Create merged transition
            merged_trans = {
                'screen': f'Screen {len(merged_transitions) + 1}',
                'screen_name': screen_name,
                'start_time': start_time,
                'end_time': end_time,
                'duration': end_time - start_time,
                'screen_frame': screen_frame
            }
            merged_transitions.append(merged_trans)
            i = j
        
        print(f"\nMerged {len(transitions)} transitions into {len(merged_transitions)} unique screens")
        transitions = merged_transitions
        
        # Renumber screens starting from Screen 1
        for i, trans in enumerate(transitions, 1):
            trans['screen'] = f'Screen {i}'
        
        print(f"Total screens detected: {len(transitions)}")
        
        return transitions
    
    def format_time_range(self, start_time, end_time):
        """Format time range as 'HH:MM:SS - HH:MM:SS'."""
        def seconds_to_time(seconds):
            td = timedelta(seconds=int(seconds))
            hours, remainder = divmod(td.seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        
        return f"{seconds_to_time(start_time)} - {seconds_to_time(end_time)}"
    
    def save_screenshot(self, frame, output_path):
        """Save a screenshot frame as an image file."""
        # Resize image to reasonable size for Excel (max width 300px)
        height, width = frame.shape[:2]
        max_width = 300
        if width > max_width:
            scale = max_width / width
            new_width = max_width
            new_height = int(height * scale)
            frame = cv2.resize(frame, (new_width, new_height))
        
        # Convert BGR to RGB for PIL
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        pil_image = Image.fromarray(rgb_frame)
        
        # Save as PNG
        pil_image.save(output_path, 'PNG')
        return output_path
    
    def create_excel_report(self, transitions, output_filename=None):
        """Create Excel file with screen transitions and screenshots."""
        if not transitions:
            print("Warning: No transitions detected. Creating empty report.")
            return None
        
        # Prepare data for Excel
        data = []
        screenshot_paths = []
        
        # Create temporary directory for screenshots
        temp_dir = tempfile.mkdtemp()
        
        print("\nSaving screenshots...")
        for i, trans in enumerate(tqdm(transitions, desc="Saving screenshots", unit="screen")):
            time_range = self.format_time_range(trans['start_time'], trans['end_time'])
            data.append({
                'Screen': trans['screen'],
                'Time Range': time_range
            })
            
            # Save screenshot if frame is available
            screenshot_path = None
            if trans.get('screen_frame') is not None:
                screenshot_path = os.path.join(temp_dir, f'screen_{i+1}.png')
                self.save_screenshot(trans['screen_frame'], screenshot_path)
            screenshot_paths.append(screenshot_path)
        
        df = pd.DataFrame(data)
        
        # Create Excel file with custom filename if provided
        if output_filename:
            output_file = self.output_folder / output_filename
        else:
            output_file = self.output_folder / "ScreenTransitions.xlsx"
        
        # Try to write, handle if file is open
        try:
            # Create workbook manually to have control over column order
            from openpyxl import Workbook
            wb = Workbook()
            ws = wb.active
            ws.title = 'Screen Transitions'
            
            # Set headers
            ws['A1'] = 'Screenshot'
            ws['B1'] = 'Screen'
            ws['C1'] = 'Time Range'
            
            # Insert screenshots and data
            print("\nInserting screenshots into Excel...")
            for i, (row_data, screenshot_path) in enumerate(zip(data, screenshot_paths)):
                row_num = i + 2  # Start from row 2 (row 1 is header)
                
                # Insert screenshot in column A
                if screenshot_path and os.path.exists(screenshot_path):
                    try:
                        img = XLImage(screenshot_path)
                        # Resize image to fit cell (approximately 80px height)
                        img.height = 80
                        if img.width > 150:
                            img.width = 150
                        
                        # Anchor image to cell
                        cell_address = f'A{row_num}'
                        ws.add_image(img, cell_address)
                        
                        # Adjust row height to fit image
                        ws.row_dimensions[row_num].height = 65
                    except Exception as e:
                        # If image insertion fails, continue
                        pass
                
                # Insert data in columns B and C
                ws.cell(row=row_num, column=2, value=row_data['Screen'])
                ws.cell(row=row_num, column=3, value=row_data['Time Range'])
            
            # Adjust column widths
            ws.column_dimensions['A'].width = 22  # Screenshot column
            ws.column_dimensions['B'].width = 15  # Screen column
            ws.column_dimensions['C'].width = 25  # Time Range column
            
            # Save workbook
            wb.save(output_file)
            
            # Clean up temporary screenshots
            try:
                import shutil
                shutil.rmtree(temp_dir)
            except:
                pass
            
            print(f"\nExcel report saved: {output_file}")
        except PermissionError:
            print(f"\nWarning: Could not save Excel file. Please close {output_file} if it's open and try again.")
            # Clean up temp directory
            try:
                import shutil
                shutil.rmtree(temp_dir)
            except:
                pass
            return None
        
        return output_file
    
    def run(self, output_filename=None):
        """Run the complete analysis."""
        print("\n" + "=" * 70)
        print("DURATION ANALYZER")
        print("=" * 70)
        print(f"\nConfiguration:")
        print(f"  - Video: {self.video_path.name}")
        print(f"  - Frame sampling: Every {self.frame_sampling_rate} seconds")
        print(f"  - Similarity threshold: {self.similarity_threshold}")
        
        # Analyze video
        transitions = self.analyze_video()
        
        # Create Excel report
        output_file = self.create_excel_report(transitions, output_filename=output_filename)
        
        print("\n" + "=" * 70)
        print("ANALYSIS COMPLETE!")
        print("=" * 70)
        print(f"\nSummary:")
        print(f"  - Total screens detected: {len(transitions)}")
        print(f"  - Report saved: {output_file}")
        
        return output_file


if __name__ == "__main__":
    # Default configuration
    video_path = "videos/video.mp4"
    analyzer = ScreenTransitionAnalyzer(
        video_path=video_path,
        output_folder="results",
        frame_sampling_rate=0.5,  # Sample every 0.5 seconds
        similarity_threshold=0.90  # 90% similarity threshold
    )
    analyzer.run()

