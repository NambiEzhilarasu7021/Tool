# Duration Analyzer - Shareable Package

## Quick Start Guide

### Step 1: Install Python
If Python is not installed, download and install it from: https://www.python.org/downloads/
- During installation, make sure to check "Add Python to PATH"

### Step 2: Install Python Dependencies
Open Command Prompt or PowerShell in this folder and run:
```bash
pip install -r requirements.txt
```

Or if that doesn't work:
```bash
python -m pip install -r requirements.txt
```

### Step 3: Install Tesseract OCR (Optional - for text extraction)
**Windows:**
1. Download from: https://github.com/UB-Mannheim/tesseract/wiki
2. Install to default location: `C:\Program Files\Tesseract-OCR`
3. Or use winget: `winget install --id UB-Mannheim.TesseractOCR`

**Note:** The app will work without Tesseract, but text extraction from screens will be disabled.

### Step 4: Run the Application

**Option A - Using PowerShell script:**
```bash
powershell -ExecutionPolicy Bypass -File run_streamlit.ps1
```

**Option B - Using Python directly:**
```bash
python -m streamlit run app.py
```

The application will open in your browser at: http://localhost:8501

## Features

1. **Upload Videos**: Upload up to 3 videos (MP4, AVI, MOV, MKV)
2. **Automatic Analysis**: Automatic screen transition detection
3. **Manual Selection**: 
   - View screenshots at 1-second intervals
   - Click "Start" and "End" buttons to mark screen boundaries
   - Screenshots between Start/End are automatically hidden
4. **Excel Reports**: 
   - Individual reports for each video
   - Combined report with separate sheets for Iteration 1, 2, 3

## How to Use Manual Selection

1. After analysis, scroll to "Manual Screen Selection" section
2. Click "🟢 Start" on a screenshot to mark the beginning of a screen
3. Click "🔴 End" on a later screenshot to mark the end of that screen
4. All screenshots between Start and End will disappear
5. Repeat for all videos
6. Click "Generate Combined Report" to create Excel with separate sheets for each iteration

## Troubleshooting

**"streamlit is not recognized"**
- Use: `python -m streamlit run app.py` instead

**"Tesseract not found"**
- Install Tesseract OCR (see Step 3) or the app will work without text extraction

**"No module named 'cv2'"**
- Run: `pip install -r requirements.txt` to install all dependencies

## Support

If you encounter any issues, make sure:
- Python 3.8+ is installed
- All dependencies are installed (`pip install -r requirements.txt`)
- You're running the command from the correct directory
