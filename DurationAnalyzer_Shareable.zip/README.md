# Screen Transition Analyzer

Analyzes video files to detect screen transitions and extract screen names using OCR.

## Installation

### 1. Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 2. Install Tesseract OCR

The tool uses Tesseract OCR to extract text from video frames. You need to install Tesseract on your system:

**Windows:**
1. Download Tesseract installer from: https://github.com/UB-Mannheim/tesseract/wiki
2. Install it (default location: `C:\Program Files\Tesseract-OCR`)
3. Add Tesseract to your PATH, or the tool will try to find it automatically

**Alternative (if Tesseract not in PATH):**
Edit `screen_transition_analyzer.py` and add this line after imports:
```python
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
```

## Usage

### Web UI (Recommended)

Launch the Streamlit web interface to upload and analyze up to 3 videos:

```bash
streamlit run app.py
```

The UI will open in your browser where you can:
1. Upload up to 3 videos (MP4, AVI, MOV, MKV formats)
2. Adjust configuration settings (frame sampling rate, similarity threshold)
3. Run the analysis
4. Download the Excel results for each video

### Command Line

For single video analysis via command line:

```bash
python run_transition_analyzer.py
```

## Output

Creates Excel files (`results/ScreenTransitions_Video1.xlsx`, etc.) with:
- **Screenshot**: Thumbnail image of each screen
- **Screen**: Screen number (Screen 1, Screen 2, etc.)
- **Screen Name**: Text extracted from the screen using OCR
- **Time Range**: Start and end time of each screen (HH:MM:SS format)

## Configuration

### In Web UI:
- Adjust settings using the sidebar sliders before running analysis

### In Command Line:
Edit `run_transition_analyzer.py` to adjust:
- `frame_sampling_rate`: How often to sample frames (default: 0.5 seconds)
- `similarity_threshold`: Threshold for detecting transitions (default: 0.90)

