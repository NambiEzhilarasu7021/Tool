# Streamlit launcher script
$env:STREAMLIT_BROWSER_GATHER_USAGE_STATS = "false"

# Run streamlit and pipe empty input to skip email prompt
echo "" | python -m streamlit run app.py

