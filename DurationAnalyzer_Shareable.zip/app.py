"""
Streamlit UI for Duration Analyzer
Allows uploading 3 videos and generating Excel reports for each.
"""

import streamlit as st
import tempfile
import os
from pathlib import Path
from screen_transition_analyzer import ScreenTransitionAnalyzer
import time
import base64
from PIL import Image
import io

# Page configuration
st.set_page_config(
    page_title="Duration Analyzer",
    page_icon="🎬",
    layout="wide"
)

# Title
st.title("🎬 Duration Analyzer")
st.markdown("Upload up to 3 videos to analyze screen transitions and generate Excel reports.")

# Initialize session state
if 'results' not in st.session_state:
    st.session_state.results = {}
if 'analysis_complete' not in st.session_state:
    st.session_state.analysis_complete = False
if 'screenshots' not in st.session_state:
    st.session_state.screenshots = {}
if 'start_markers' not in st.session_state:
    st.session_state.start_markers = {}  # Track which screenshots are marked as start
if 'end_markers' not in st.session_state:
    st.session_state.end_markers = {}  # Track which screenshots are marked as end

# Sidebar for configuration
with st.sidebar:
    st.header("⚙️ Configuration")
    frame_sampling_rate = st.slider(
        "Frame Sampling Rate (seconds)",
        min_value=0.1,
        max_value=2.0,
        value=0.5,
        step=0.1,
        help="How often to sample frames from the video"
    )
    similarity_threshold = st.slider(
        "Similarity Threshold",
        min_value=0.70,
        max_value=0.99,
        value=0.90,
        step=0.01,
        help="Threshold for detecting screen transitions (higher = more sensitive)"
    )

# Main content area
st.header("📤 Upload Videos")

# Create three columns for video uploads
col1, col2, col3 = st.columns(3)

uploaded_videos = {}

with col1:
    st.subheader("Video 1")
    video1 = st.file_uploader(
        "Upload first video",
        type=['mp4', 'avi', 'mov', 'mkv'],
        key="video1"
    )
    if video1:
        st.info(f"✅ {video1.name}")
        uploaded_videos[1] = video1

with col2:
    st.subheader("Video 2")
    video2 = st.file_uploader(
        "Upload second video",
        type=['mp4', 'avi', 'mov', 'mkv'],
        key="video2"
    )
    if video2:
        st.info(f"✅ {video2.name}")
        uploaded_videos[2] = video2

with col3:
    st.subheader("Video 3")
    video3 = st.file_uploader(
        "Upload third video",
        type=['mp4', 'avi', 'mov', 'mkv'],
        key="video3"
    )
    if video3:
        st.info(f"✅ {video3.name}")
        uploaded_videos[3] = video3

# Run button with info
st.markdown("---")
col_info, col_button = st.columns([2, 1])
with col_info:
    st.info("ℹ️ **Analysis Time**: Processing time depends on video length. A 1-minute video typically takes 2-5 minutes. The analysis includes frame comparison, OCR text extraction, and Excel report generation.")
with col_button:
    run_button = st.button(
        "🚀 Run Analysis",
        type="primary",
        use_container_width=True,
        disabled=len(uploaded_videos) == 0
    )

if run_button and len(uploaded_videos) > 0:
    # Clear previous results
    st.session_state.results = {}
    st.session_state.analysis_complete = False
    
    # Create persistent results directory
    persistent_results_dir = Path("results")
    persistent_results_dir.mkdir(exist_ok=True)
    
    # Create temporary directory for processing
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Save uploaded videos to temp directory
        video_paths = {}
        for video_num, uploaded_file in uploaded_videos.items():
            video_path = temp_path / f"video_{video_num}_{uploaded_file.name}"
            with open(video_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            video_paths[video_num] = video_path
        
        # Create results directory in temp
        results_dir = temp_path / "results"
        results_dir.mkdir(exist_ok=True)
        
        # Progress bar and status
        progress_bar = st.progress(0)
        status_text = st.empty()
        detail_text = st.empty()
        
        # Process each video
        total_videos = len(video_paths)
        for idx, (video_num, video_path) in enumerate(video_paths.items(), 1):
            video_name = uploaded_videos[video_num].name
            status_text.text(f"📹 Processing Video {video_num}: {video_name}")
            detail_text.text("⏳ Initializing analyzer...")
            
            try:
                # Initialize analyzer
                detail_text.text("⏳ Setting up video analysis...")
                analyzer = ScreenTransitionAnalyzer(
                    video_path=str(video_path),
                    output_folder=str(results_dir),
                    frame_sampling_rate=frame_sampling_rate,
                    similarity_threshold=similarity_threshold
                )
                
                # Run analysis with custom filename
                detail_text.text("⏳ Analyzing video frames (this may take a few minutes for long videos)...")
                output_filename = f"ScreenTransitions_Video{video_num}.xlsx"
                output_file = analyzer.run(output_filename=output_filename)
                
                detail_text.text("⏳ Extracting screenshots for manual selection...")
                # Extract screenshots at 1-second intervals to persistent location
                persistent_screenshots_dir = persistent_results_dir / f"screenshots_video{video_num}"
                persistent_screenshots_dir.mkdir(exist_ok=True)
                screenshots = analyzer.extract_screenshots_per_second(output_folder=str(persistent_screenshots_dir))
                
                detail_text.text("✅ Analysis complete!")
                
                # Copy to persistent location before temp dir is deleted
                if output_file and output_file.exists():
                    detail_text.text("💾 Saving results...")
                    persistent_file = persistent_results_dir / output_filename
                    import shutil
                    shutil.copy2(output_file, persistent_file)
                    
                    # Store result in session state with persistent path
                    st.session_state.results[video_num] = {
                        'file_path': persistent_file,
                        'video_name': video_name,
                        'status': 'success',
                        'video_path': str(video_path)  # Store original video path
                    }
                    st.session_state.screenshots[video_num] = screenshots
                    st.session_state.start_markers[video_num] = []
                    st.session_state.end_markers[video_num] = []
                    detail_text.text(f"✅ Video {video_num} completed successfully!")
                else:
                    st.session_state.results[video_num] = {
                        'video_name': video_name,
                        'status': 'error',
                        'error': 'Failed to generate Excel file'
                    }
                    detail_text.text(f"❌ Video {video_num} failed to generate Excel file")
                
            except Exception as e:
                st.error(f"❌ Error processing Video {video_num}: {str(e)}")
                st.session_state.results[video_num] = {
                    'video_name': video_name,
                    'status': 'error',
                    'error': str(e)
                }
                detail_text.text(f"❌ Error processing Video {video_num}")
            
            # Update progress
            progress_bar.progress(idx / total_videos)
            if idx < total_videos:
                detail_text.text("⏳ Preparing next video...")
        
        # Mark analysis as complete
        st.session_state.analysis_complete = True
        status_text.text("✅ All Videos Processed!")
        detail_text.text("📊 Results are ready for download below")
        progress_bar.progress(1.0)

# Display results and download buttons
if st.session_state.analysis_complete:
    st.markdown("---")
    st.header("📊 Results")
    
    # Create columns for download buttons
    download_cols = st.columns(3)
    
    for idx, (video_num, result) in enumerate(sorted(st.session_state.results.items())):
        with download_cols[idx]:
            if result['status'] == 'success':
                st.success(f"✅ Video {video_num}")
                st.caption(result['video_name'])
                
                # Read file for download
                if result['file_path'].exists():
                    with open(result['file_path'], "rb") as f:
                        st.download_button(
                            label=f"📥 Download Excel {video_num}",
                            data=f.read(),
                            file_name=f"ScreenTransitions_Video{video_num}.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            key=f"download_{video_num}",
                            use_container_width=True
                        )
            else:
                st.error(f"❌ Video {video_num}")
                st.caption(result['video_name'])
                if 'error' in result:
                    st.caption(f"Error: {result['error']}")
    
    # Manual Screen Selection Section
    st.markdown("---")
    st.header("🎯 Manual Screen Selection")
    st.markdown("""
    **Instructions:**
    1. Click "Start" button on a screenshot to mark the beginning of a screen
    2. Click "End" button on a later screenshot to mark the end of that screen
    3. All screenshots between Start and End will be considered as one screen
    4. Once Start and End are clicked, those screenshots will be disabled
    5. Repeat for additional screens in all videos
    6. Click "Generate Combined Report" to create a single Excel with all videos (Iteration 1, 2, 3)
    """)
    
    # Show screenshots for each video
    for video_num in sorted(st.session_state.results.keys()):
        if video_num in st.session_state.screenshots and st.session_state.results[video_num]['status'] == 'success':
            st.markdown(f"### Video {video_num}: {st.session_state.results[video_num]['video_name']}")
            
            screenshots = st.session_state.screenshots[video_num]
            
            # Initialize markers if not exists
            if video_num not in st.session_state.start_markers:
                st.session_state.start_markers[video_num] = []
            if video_num not in st.session_state.end_markers:
                st.session_state.end_markers[video_num] = []
            
            # Calculate which screenshots are already part of defined screens (should be hidden/disabled)
            start_markers = sorted(st.session_state.start_markers[video_num])
            end_markers = sorted(st.session_state.end_markers[video_num])
            hidden_indices = set()
            disabled_indices = set()  # Screenshots that are part of completed screens (Start, End, and between)
            
            # Find all screenshots between start and end pairs
            start_idx = 0
            end_idx = 0
            while start_idx < len(start_markers):
                start_screenshot_idx = start_markers[start_idx]
                # Find the next end marker after this start
                while end_idx < len(end_markers):
                    if end_markers[end_idx] > start_screenshot_idx:
                        end_screenshot_idx = end_markers[end_idx]
                        # Mark all screenshots from start to end (inclusive) as disabled
                        for idx in range(start_screenshot_idx, end_screenshot_idx + 1):
                            disabled_indices.add(idx)
                        # Hide screenshots between start and end (excluding start and end themselves)
                        for idx in range(start_screenshot_idx + 1, end_screenshot_idx):
                            hidden_indices.add(idx)
                        end_idx += 1
                        break
                    end_idx += 1
                start_idx += 1
            
            # Filter screenshots - only show those that are not hidden
            visible_screenshots = []
            for idx, screenshot in enumerate(screenshots):
                if idx not in hidden_indices:
                    visible_screenshots.append((idx, screenshot))
            
            # Display visible screenshots in a grid
            if len(visible_screenshots) > 0:
                cols_per_row = 5
                num_rows = (len(visible_screenshots) + cols_per_row - 1) // cols_per_row
                
                for row in range(num_rows):
                    cols = st.columns(cols_per_row)
                    for col_idx in range(cols_per_row):
                        item_idx = row * cols_per_row + col_idx
                        if item_idx < len(visible_screenshots):
                            screenshot_idx, screenshot = visible_screenshots[item_idx]
                            with cols[col_idx]:
                                # Display screenshot
                                st.image(screenshot['pil_image'], use_container_width=True)
                                
                                # Format time
                                time_str = f"{int(screenshot['time'] // 60):02d}:{int(screenshot['time'] % 60):02d}"
                                st.caption(f"Time: {time_str}s")
                                
                                # Check if this screenshot is disabled (part of a completed screen)
                                is_disabled = screenshot_idx in disabled_indices
                                is_start = screenshot_idx in st.session_state.start_markers[video_num]
                                is_end = screenshot_idx in st.session_state.end_markers[video_num]
                                
                                # Start and End buttons
                                col_start, col_end = st.columns(2)
                                
                                with col_start:
                                    start_button_key = f"start_v{video_num}_s{screenshot_idx}"
                                    if is_disabled:
                                        st.button("🟢 Start", key=start_button_key, use_container_width=True, disabled=True)
                                        if is_start:
                                            st.caption("✓ Start (Used)")
                                    else:
                                        if st.button("🟢 Start", key=start_button_key, use_container_width=True):
                                            if screenshot_idx not in st.session_state.start_markers[video_num]:
                                                st.session_state.start_markers[video_num].append(screenshot_idx)
                                                st.session_state.start_markers[video_num].sort()
                                            st.rerun()
                                
                                with col_end:
                                    end_button_key = f"end_v{video_num}_s{screenshot_idx}"
                                    if is_disabled:
                                        st.button("🔴 End", key=end_button_key, use_container_width=True, disabled=True)
                                        if is_end:
                                            st.caption("✓ End (Used)")
                                    else:
                                        if st.button("🔴 End", key=end_button_key, use_container_width=True):
                                            if screenshot_idx not in st.session_state.end_markers[video_num]:
                                                st.session_state.end_markers[video_num].append(screenshot_idx)
                                                st.session_state.end_markers[video_num].sort()
                                            st.rerun()
            else:
                st.info("All screenshots have been assigned to screens. You can generate the Excel report now.")
            
            # Show markers summary
            start_count = len(st.session_state.start_markers[video_num])
            end_count = len(st.session_state.end_markers[video_num])
            if start_count > 0 or end_count > 0:
                st.info(f"Start markers: {start_count} | End markers: {end_count}")
                
                # Generate Excel button
                if st.button(f"📊 Generate Excel from Selections - Video {video_num}", key=f"generate_manual_{video_num}"):
                    # Process Start/End markers to create screens
                    start_markers = sorted(st.session_state.start_markers[video_num])
                    end_markers = sorted(st.session_state.end_markers[video_num])
                    
                    screens = []
                    screen_number = 1
                    
                    if len(start_markers) == 0:
                        st.warning("Please mark at least one Start point")
                    else:
                        # Match start and end markers
                        start_idx = 0
                        end_idx = 0
                        
                        while start_idx < len(start_markers):
                            start_screenshot_idx = start_markers[start_idx]
                            start_screenshot = screenshots[start_screenshot_idx]
                            
                            # Find the next end marker after this start marker
                            end_screenshot_idx = None
                            while end_idx < len(end_markers):
                                if end_markers[end_idx] > start_screenshot_idx:
                                    end_screenshot_idx = end_markers[end_idx]
                                    end_idx += 1
                                    break
                                end_idx += 1
                            
                            if end_screenshot_idx is not None:
                                # Found matching end marker
                                end_screenshot = screenshots[end_screenshot_idx]
                                screens.append({
                                    'screen': f'Screen {screen_number}',
                                    'screen_name': f'Screen {screen_number}',
                                    'start_time': start_screenshot['time'],
                                    'end_time': end_screenshot['time'],
                                    'duration': end_screenshot['time'] - start_screenshot['time'],
                                    'screen_frame': start_screenshot['frame']
                                })
                                screen_number += 1
                                start_idx += 1
                            else:
                                # No end marker found - screen continues to end of video
                                last_video_screenshot = screenshots[-1]
                                screens.append({
                                    'screen': f'Screen {screen_number}',
                                    'screen_name': f'Screen {screen_number}',
                                    'start_time': start_screenshot['time'],
                                    'end_time': last_video_screenshot['time'],
                                    'duration': last_video_screenshot['time'] - start_screenshot['time'],
                                    'screen_frame': start_screenshot['frame']
                                })
                                screen_number += 1
                                start_idx += 1
                        
                        if len(screens) > 0:
                            # Generate Excel
                            try:
                                from screen_transition_analyzer import ScreenTransitionAnalyzer
                                import tempfile
                                
                                # Get persistent results directory
                                persistent_results_dir = Path("results")
                                persistent_results_dir.mkdir(exist_ok=True)
                                
                                # Create a temporary analyzer instance just for Excel generation
                                # We need a valid video path, so we'll use a dummy one
                                with tempfile.NamedTemporaryFile(suffix='.mp4', delete=False) as tmp_video:
                                    tmp_video_path = tmp_video.name
                                
                                analyzer = ScreenTransitionAnalyzer(
                                    video_path=tmp_video_path,
                                    output_folder=str(persistent_results_dir)
                                )
                                
                                output_filename = f"ScreenTransitions_Manual_Video{video_num}.xlsx"
                                output_file = analyzer.create_excel_report(screens, output_filename=output_filename)
                                
                                # Clean up temp file
                                try:
                                    os.unlink(tmp_video_path)
                                except:
                                    pass
                                
                                if output_file and output_file.exists():
                                    st.success(f"✅ Excel file generated: {output_filename}")
                                    with open(output_file, "rb") as f:
                                        st.download_button(
                                            label=f"📥 Download Manual Excel {video_num}",
                                            data=f.read(),
                                            file_name=output_filename,
                                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                            key=f"download_manual_{video_num}"
                                        )
                                else:
                                    st.error("Failed to generate Excel file")
                            except Exception as e:
                                st.error(f"Error generating Excel: {str(e)}")
                        else:
                            st.warning("No valid screen pairs found. Please mark Start and End points.")
            
            st.markdown("---")
    
    # Combined Report Generation
    if st.session_state.analysis_complete:
        st.markdown("---")
        st.header("📊 Combined Report Generation")
        st.markdown("Generate a single Excel report with all videos as Iteration 1, Iteration 2, and Iteration 3")
        
        if st.button("📊 Generate Combined Report (All Videos)", key="generate_combined", type="primary"):
            try:
                from screen_transition_analyzer import ScreenTransitionAnalyzer
                import tempfile
                from openpyxl import Workbook
                from openpyxl.drawing.image import Image as XLImage
                import shutil
                
                # Get persistent results directory
                persistent_results_dir = Path("results")
                persistent_results_dir.mkdir(exist_ok=True)
                
                # Create a temporary analyzer instance just for Excel generation
                with tempfile.NamedTemporaryFile(suffix='.mp4', delete=False) as tmp_video:
                    tmp_video_path = tmp_video.name
                
                analyzer = ScreenTransitionAnalyzer(
                    video_path=tmp_video_path,
                    output_folder=str(persistent_results_dir)
                )
                
                # Process all videos and collect screens by iteration
                iterations_data = {}
                iteration_names = {1: "Iteration 1", 2: "Iteration 2", 3: "Iteration 3"}
                
                for video_num in sorted(st.session_state.results.keys()):
                    if (video_num in st.session_state.screenshots and 
                        st.session_state.results[video_num]['status'] == 'success' and
                        video_num in st.session_state.start_markers and
                        video_num in st.session_state.end_markers):
                        
                        iteration_name = iteration_names.get(video_num, f"Video {video_num}")
                        screenshots = st.session_state.screenshots[video_num]
                        start_markers = sorted(st.session_state.start_markers[video_num])
                        end_markers = sorted(st.session_state.end_markers[video_num])
                        
                        screens = []
                        # Match start and end markers
                        start_idx = 0
                        end_idx = 0
                        screen_number = 1
                        
                        while start_idx < len(start_markers):
                            start_screenshot_idx = start_markers[start_idx]
                            start_screenshot = screenshots[start_screenshot_idx]
                            
                            # Find the next end marker after this start
                            end_screenshot_idx = None
                            while end_idx < len(end_markers):
                                if end_markers[end_idx] > start_screenshot_idx:
                                    end_screenshot_idx = end_markers[end_idx]
                                    end_idx += 1
                                    break
                                end_idx += 1
                            
                            if end_screenshot_idx is not None:
                                end_screenshot = screenshots[end_screenshot_idx]
                                screens.append({
                                    'screen': f'Screen {screen_number}',
                                    'screen_name': f'Screen {screen_number}',
                                    'start_time': start_screenshot['time'],
                                    'end_time': end_screenshot['time'],
                                    'duration': end_screenshot['time'] - start_screenshot['time'],
                                    'screen_frame': start_screenshot['frame']
                                })
                                screen_number += 1
                                start_idx += 1
                            else:
                                # No end marker found - screen continues to end of video
                                last_video_screenshot = screenshots[-1]
                                screens.append({
                                    'screen': f'Screen {screen_number}',
                                    'screen_name': f'Screen {screen_number}',
                                    'start_time': start_screenshot['time'],
                                    'end_time': last_video_screenshot['time'],
                                    'duration': last_video_screenshot['time'] - start_screenshot['time'],
                                    'screen_frame': start_screenshot['frame']
                                })
                                screen_number += 1
                                start_idx += 1
                        
                        if len(screens) > 0:
                            iterations_data[iteration_name] = screens
                
                if len(iterations_data) > 0:
                    # Generate combined Excel with multiple sheets
                    output_filename = "ScreenTransitions_Combined_Report.xlsx"
                    output_file = analyzer.create_multi_sheet_excel_report(iterations_data, output_filename=output_filename)
                    
                    # Clean up temp file
                    try:
                        os.unlink(tmp_video_path)
                    except:
                        pass
                    
                    if output_file and output_file.exists():
                        total_screens = sum(len(screens) for screens in iterations_data.values())
                        st.success(f"✅ Combined Excel file generated: {output_filename}")
                        st.info(f"Total screens: {total_screens} across {len(iterations_data)} iteration(s)")
                        st.info(f"Sheets created: {', '.join(iterations_data.keys())}")
                        with open(output_file, "rb") as f:
                            st.download_button(
                                label="📥 Download Combined Excel Report",
                                data=f.read(),
                                file_name=output_filename,
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                key="download_combined"
                            )
                    else:
                        st.error("Failed to generate combined Excel file")
                else:
                    st.warning("No screens found. Please mark Start and End points in at least one video.")
                    
                    # Clean up temp file
                    try:
                        os.unlink(tmp_video_path)
                    except:
                        pass
                    
            except Exception as e:
                st.error(f"Error generating combined Excel: {str(e)}")

# Footer
st.markdown("---")
st.markdown(
    """
    <div style='text-align: center; color: gray;'>
        <p>Duration Analyzer - Upload videos to analyze screen transitions</p>
    </div>
    """,
    unsafe_allow_html=True
)

